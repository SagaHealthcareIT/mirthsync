// Modify the message variable below to pre process data
// This script applies across all channels
return message;
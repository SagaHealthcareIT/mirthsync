// This script executes once for each deploy or redeploy task
// You only have access to the globalMap here to persist data
return;
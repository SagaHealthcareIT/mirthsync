// This script executes once for each deploy, undeploy, or redeploy task
// if at least one channel was undeployed
// You only have access to the globalMap here to persist data
return;
/**
	Modify the description here. Modify the function name and parameters as needed. One function per
	template is recommended; create a new code template for each new function.

	@param {String} arg1 - arg1 description
	@return {String} return description
*/
function template_2_library_2(arg1) {
	// TODO: Enter code here
}
// Modify the message variable below to pre process data
logger.info('http hello2 preprocessor');
return message;
var foo=1;
// hello there
return "Hello world2";
var foo='this is step 1';
// step 1 in the source filter
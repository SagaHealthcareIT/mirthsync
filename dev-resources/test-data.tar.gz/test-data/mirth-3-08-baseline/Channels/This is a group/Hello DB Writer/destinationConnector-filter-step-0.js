// this is an unnamed script step
var foo=null;
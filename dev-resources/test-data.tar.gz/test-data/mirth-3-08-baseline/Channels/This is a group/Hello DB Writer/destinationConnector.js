// this is my unnamed javascript writer destination setting area
var foo=null;
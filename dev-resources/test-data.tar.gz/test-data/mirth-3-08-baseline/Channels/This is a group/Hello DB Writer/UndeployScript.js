// This script executes once when the channel is undeployed
// You only have access to the globalMap and globalChannelMap here to persist data
logger.info('hello db writer undeploy');
return;
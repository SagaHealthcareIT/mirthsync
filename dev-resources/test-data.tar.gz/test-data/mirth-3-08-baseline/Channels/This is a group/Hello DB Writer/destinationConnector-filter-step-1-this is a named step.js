// named step
var foo=null;
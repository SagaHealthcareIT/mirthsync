// Modify the message variable below to pre process data
logger.info('hello db writer preprocessor');
return message;
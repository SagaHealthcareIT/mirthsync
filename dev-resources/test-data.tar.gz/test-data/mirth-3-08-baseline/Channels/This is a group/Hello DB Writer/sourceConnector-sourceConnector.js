var foo='foo';

// this is a javascript reader source js area

var foo2='foo2';
// this is step 2
var foo='hello there';
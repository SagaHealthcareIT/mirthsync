// This script executes once after a message has been processed
// Responses returned from here will be stored as "Postprocessor" in the response map
logger.info('hello db writer postprocessor');
return;
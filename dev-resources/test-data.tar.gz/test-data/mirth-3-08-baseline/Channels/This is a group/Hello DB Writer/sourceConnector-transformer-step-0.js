var unnamedsourcetransformer=1;

// foo